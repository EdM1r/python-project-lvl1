#!/usr/bin/env python
#test project for hexlet lvl1 

def main():
  print('Welcome to Brain Games!')

if __name__ == '__main__':
  main()

